package com.example.android.scorekeeperapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private final int KILL = 1;
    private final int DOUBLEKILL = 2;
    private final int TRIPLEKILL = 3;
    private final int QUADRAKILL = 4;
    private final int PENTAKILL = 5;

    private int numBlueKills = 0;
    private int numBlueTurrets = 0;
    private int numRedKills = 0;
    private int numRedTurrets = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void displayBlueKills() {
        TextView killsBlueView = (TextView) findViewById(R.id.kills_blue_team);
        killsBlueView.setText(String.valueOf(numBlueKills));
    }

    private void displayBlueTurrets() {
        TextView turretsBlueView = (TextView) findViewById(R.id.turrets_blue_team);
        turretsBlueView.setText(String.valueOf(numBlueTurrets));
    }

    private void displayRedKills() {
        TextView killsRedView = (TextView) findViewById(R.id.kills_red_team);
        killsRedView.setText(String.valueOf(numRedKills));
    }

    private void displayRedTurrets() {
        TextView turretsRedView = (TextView) findViewById(R.id.turrets_red_team);
        turretsRedView.setText(String.valueOf(numRedTurrets));
    }

    public void pentaKillRedTeam(View view) {
        numRedKills += PENTAKILL;
        displayRedKills();
    }

    public void quadraKillRedTeam(View view) {
        numRedKills += QUADRAKILL;
        displayRedKills();
    }

    public void tripleKillRedTeam(View view) {
        numRedKills += TRIPLEKILL;
        displayRedKills();
    }

    public void doubleKillRedTeam(View view) {
        numRedKills += DOUBLEKILL;
        displayRedKills();
    }

    public void killRedTeam(View view) {
        numRedKills += KILL;
        displayRedKills();
    }

    public void destroyedTurretRedTeam(View view) {
        if (numRedTurrets < 11) {
            numRedTurrets++;
            displayRedTurrets();
        }
    }

    public void pentaKillBlueTeam(View view) {
        numBlueKills += PENTAKILL;
        displayBlueKills();
    }

    public void quadraKillBlueTeam(View view) {
        numBlueKills += QUADRAKILL;
        displayBlueKills();
    }

    public void tripleKillBlueTeam(View view) {
        numBlueKills += TRIPLEKILL;
        displayBlueKills();
    }

    public void doubleKillBlueTeam(View view) {
        numBlueKills += DOUBLEKILL;
        displayBlueKills();
    }

    public void killBlueTeam(View view) {
        numBlueKills += KILL;
        displayBlueKills();
    }

    public void destroyedTurretBlueTeam(View view) {
        if (numBlueTurrets < 11) {
            numBlueTurrets++;
            displayBlueTurrets();
        }
    }

    public void reset(View view) {
        numRedKills = 0;
        numBlueKills = 0;
        numRedTurrets = 0;
        numBlueTurrets = 0;
        displayRedKills();
        displayBlueKills();
        displayRedTurrets();
        displayBlueTurrets();
    }
}
